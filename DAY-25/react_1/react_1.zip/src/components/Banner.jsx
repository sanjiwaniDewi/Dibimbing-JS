const Banner = () => {
    return (
        <img
            src="https://upload.wikimedia.org/wikipedia/commons/e/e1/Pemandangan_Gunung_Bromo.jpg"
            alt="react"
        />
    );
};

export default Banner;
