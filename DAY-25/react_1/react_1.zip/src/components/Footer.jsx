const Footer = () => {
    const nav = ["Need Help?", "Job", "Contact Us"];
    return (
        <div>
            {nav.map((item) => (
                <li>{item}</li>
            ))}
        </div>
    );
};

export default Footer;
